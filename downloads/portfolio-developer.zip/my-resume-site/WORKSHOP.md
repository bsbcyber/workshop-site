# Workshop 1 journey — follow along in VS Code

Open this file beside your editor (**View → Editor Layout → Two Columns**). Check boxes as you go.

**Where you work**

| Label | Meaning |
| --- | --- |
| **VS Code** | Clicks or typing inside Visual Studio Code |
| **Terminal** | The panel at the bottom of VS Code (or a second terminal tab) |
| **GitHub** | Your browser on github.com |
| **Browser** | Local preview (`localhost`) or your live site |

**Goal:** build out *your* resume in this starter → open a real pull request tied to an issue → publish on GitHub Pages.

### Git words (read once)

| Word | Plain English |
| --- | --- |
| **Repository (repo)** | The project folder plus its history |
| **Commit** | A named checkpoint saved on your laptop |
| **Push** | Upload your commits to GitHub |
| **Branch** | A named line of work (we keep feature work off `main` until reviewed) |
| **Stage (+)** | Choose which edited files go into the next commit |
| **Pull request (PR)** | A GitHub page to review a branch before merging into `main` |
| **Merge** | Accept the PR so those commits land on `main` |

**Rule when stuck:** in **Terminal**, run `git status` and read the first lines (which branch? what changed?). Then ask for help with that output.

---

## Before you start

- [ ] **GitHub** — signed in at [github.com](https://github.com)
- [ ] **VS Code** — installed and open
- [ ] **Terminal** (in VS Code) — these print version numbers:

```bash
git --version
node --version
npm --version
```

Prefer Node.js **22**. Node 18+ usually works locally.

**VS Code map:** Activity Bar (far left icons) · Side Bar · Editor (center) · Status Bar (very bottom — shows branch name).

---

## Step 1 — Open this folder · VS Code

You should already have unzipped the starter into `my-resume-site`.

- [ ] **VS Code** · **File → Open Folder…** → select `my-resume-site` (you should see `package.json`, `src`, `public`, `WORKSHOP.md`)
- [ ] **VS Code** · Trust the authors if asked
- [ ] **VS Code** · **Terminal → New Terminal**

---

## Step 2 — Create an empty repository · GitHub

- [ ] **GitHub** · open [github.com/new](https://github.com/new)
- [ ] **GitHub** · name it something like `my-resume-site`
- [ ] **GitHub** · choose **Public**
- [ ] **GitHub** · leave **Add a README**, license, and .gitignore **unchecked**
- [ ] **GitHub** · click **Create repository**
- [ ] **GitHub** · copy the HTTPS URL into a note  
  (`https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git`)

Do not push yet.

---

## Step 3 — Run locally, then first push · VS Code + Terminal + GitHub

### 3a · Preview · Terminal

```bash
npm install
npm run dev
```

- [ ] **Terminal** · wait until `npm install` finishes (can take 1–2 minutes)
- [ ] **Browser** · open the `localhost` link from the terminal (usually `http://localhost:4321`)
- [ ] **Browser** · you see the sample resume

Keep that terminal running. In **VS Code**, click **+** in the terminal panel title bar to open a **second** terminal for Git.

### 3b · First push · Terminal (one command at a time)

Click inside the **second** terminal. You should see `my-resume-site` in the path. Run **one line, then Enter**, and only continue if it succeeds.

**1 — Start Git history**

```bash
git init
```

You should see something like `Initialized empty Git repository`.

**2 — Stage all project files** (selects what the next commit will include)

```bash
git add .
```

**3 — Check what is staged**

```bash
git status
```

You should see many files in green / “to be committed,” including `src/data/profile.js` and `.github/workflows/deploy.yml`.

**4 — Save the first checkpoint**

```bash
git commit -m "Create my portfolio"
```

If Git says **Author identity unknown**, run these first (use your name + [GitHub noreply email](https://github.com/settings/emails)), then retry the commit:

```bash
git config --global user.name "Your Name"
git config --global user.email "YOUR-GITHUB-NOREPLY-EMAIL"
```

**5 — Name the main branch**

```bash
git branch -M main
```

**6 — Connect this folder to your GitHub repo**  
Replace the URL with the one you copied in Step 2:

```bash
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
```

If it says `remote origin already exists`, run `git remote -v` to see where it points. Ask a facilitator before changing it.

**7 — Upload to GitHub**

```bash
git push -u origin main
```

- [ ] **GitHub** · refresh your repo — your files are there
- [ ] **GitHub** · **Actions** may show a **red X** on deploy. That is normal. Do **not** rewrite files to “fix” it yet — Pages is Step 6.

**If push asks for a password:** GitHub will **not** accept your normal account password. Prefer the browser sign-in window if it opens. Or create a [Personal Access Token](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token) with `repo` scope and paste that as the password (username = your GitHub username). Do not force-push.

---

## Step 4 — Build out your resume · VS Code (+ Browser for preview)

Stay on `main`. **Do not Commit / Sync in Source Control yet.**

- [ ] **VS Code** · Explorer → `src` → `data` → `profile.js`
- [ ] **VS Code** · replace name, role, about, email, GitHub, LinkedIn (no `example.com` leftovers)
- [ ] **VS Code** · update skills, education, coursework, activities
- [ ] **VS Code** · leave `experience: []` if you have none yet
- [ ] **VS Code** · edit or add a project (include a `slug` like `inventory-tracker`)
- [ ] **VS Code** · optional: add `public/photo.jpg` and set `photo: '/photo.jpg'`
- [ ] **VS Code** · save (`Cmd`/`Ctrl`+`S`) — a white dot on the tab means unsaved
- [ ] **Browser** · refresh localhost · check desktop and narrow width
- [ ] **VS Code** · Source Control may show a number badge — that is fine. Still **do not** click Commit yet

---

## Step 5 — Issue → branch → commit → pull request

Yes: you create a real GitHub **issue**, then a real **pull request**, and you **link them** so merging the PR closes the issue.

### 5a · Create the issue · GitHub

- [ ] **GitHub** · your repo → **Issues** → **New issue**
- [ ] **GitHub** · if you see **Featured project**, choose it (comes from this starter). Otherwise paste the template below.
- [ ] **GitHub** · click **Create**
- [ ] **GitHub** · note the issue number in the URL or title (e.g. `#1`)

#### Issue body — copy this

**Title:** `Add a featured project card`

```markdown
## What I’m adding or updating

Featured project card for: [your project name]

## Done when

- [ ] Project title and summary are honest (my real work)
- [ ] Link works (repo, demo, or doc) — not an example.com placeholder
- [ ] Looks readable on a phone-width browser window
- [ ] No secrets, passwords, or private personal details in the change

## Notes

[optional]
```

(Same text ships in `.github/ISSUE_TEMPLATE/featured-project.md` so GitHub can offer it automatically after your first push.)

### 5b · Create the branch · VS Code

Your uncommitted Step 4 edits will move onto the new branch — that is what we want.

- [ ] **VS Code** · look at the **Status Bar** (very bottom left). It should say `main`
- [ ] **VS Code** · click that word `main`
- [ ] **VS Code** · choose **Create new branch…** (sometimes **Create new branch from…**)
- [ ] **VS Code** · type exactly `add-featured-project` → Enter
- [ ] **VS Code** · Status Bar now shows `add-featured-project` — do not continue until it does

Optional check (**Terminal**): `git status` should say `On branch add-featured-project`.

### 5c · Match the issue · VS Code + Browser

- [ ] **VS Code** · finish the featured project (and any other resume edits) in `profile.js`
- [ ] **VS Code** · save
- [ ] **Browser** · refresh localhost and check it

### 5d · Commit and publish the branch · VS Code

This is the same idea as the terminal `git add` / `git commit` / `git push`, using buttons.

- [ ] **VS Code** · Activity Bar (far left) → click the **Source Control** icon (branch / fork shape; often has a number badge)
- [ ] **VS Code** · under **Changes**, click `profile.js` once — read the green/red diff
- [ ] **VS Code** · click **+** next to the file (or next to **Changes**) to **Stage** it — the file moves under **Staged Changes**
- [ ] **VS Code** · in the message box at the top, type e.g. `Add featured project card` (not `updates`)
- [ ] **VS Code** · click **Commit** (checkmark). If it offers to stage *all* files, only continue if you meant to include them
- [ ] **VS Code** · click **Publish Branch** (wording may be **Sync Changes** or a cloud icon). Approve **GitHub** sign-in if a browser window opens

After this, **GitHub** should show a branch named `add-featured-project`.

### 5e · Open the pull request and tie it to the issue · GitHub

- [ ] **GitHub** · refresh the repo → yellow banner **Compare & pull request** (or **Pull requests → New**)
- [ ] **GitHub** · confirm **base:** `main` and **compare:** `add-featured-project`
- [ ] **GitHub** · paste this in the PR description (use **your** issue number):

```markdown
Closes #1

## Summary
Ships the featured project card and my resume personalization from Workshop 1.

## Tested
- [ ] Localhost looks right on desktop and narrow width
- [ ] Project / profile links are mine (not example.com)
```

`Closes #1` (or `#2`, etc.) is what **links the PR to the issue**. When you merge, GitHub **auto-closes** that issue.

- [ ] **GitHub** · **Create pull request**
- [ ] **GitHub** · open **Files changed** — does it match the issue?
- [ ] **GitHub** · on the issue page, confirm the PR appears under “Development” / linked pull requests
- [ ] **GitHub** · **Merge pull request** → **Confirm merge** → delete branch if offered
- [ ] **GitHub** · issue should show **Closed** (because of `Closes #…`)

#### Optional · same Step 5d in Terminal

Only if Source Control is confusing. Second terminal tab:

```bash
git status
git add src/data/profile.js
git commit -m "Add featured project card"
git push -u origin add-featured-project
```

Then continue with **5e** on **GitHub**.

---

## Step 6 — Actions and Pages · VS Code (look) + GitHub (click)

Your ZIP already includes `.github/workflows/deploy.yml`. You do not write YAML today.

### What the workflow does

1. **When:** push / merge to `main`
2. **Build:** `npm install` → `npm run build`
3. **Deploy:** publish to GitHub Pages  
   Feature branches do **not** publish.

### Turn Pages on

- [ ] **VS Code** · open `.github/workflows/deploy.yml` once so you recognize it
- [ ] **GitHub** · **Settings → Pages**
- [ ] **GitHub** · **Build and deployment → Source** = **GitHub Actions**
- [ ] **GitHub** · **Actions** tab → open **Build and deploy portfolio**
- [ ] **GitHub** · if it failed earlier: **Re-run all jobs**
- [ ] **GitHub** · wait for green
- [ ] **GitHub** · **Settings → Pages** → open the site URL  
  (`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`)
- [ ] **Browser** · check homepage, photo (if any), a project link, narrow window

---

## If something breaks

| Symptom | Where | Try this |
| --- | --- | --- |
| Not sure what Git is doing | Terminal | `git status` — read branch name + changed files |
| Author identity unknown | Terminal | Set `user.name` / `user.email` (Step 3b), retry commit |
| Push asks for a password | Terminal / GitHub | Browser login or PAT with `repo` — not your account password |
| `remote origin already exists` | Terminal | `git remote -v` — ask before changing |
| Accidental commit on `main` | VS Code / facilitator | Stop; tell a helper your Status Bar branch name |
| Publish Branch missing | VS Code | Look for **Sync Changes** / cloud icon, or use the optional terminal push in 5d |
| Actions deploy failed | GitHub | Pages Source = GitHub Actions, then Re-run all jobs |
| 404 on the live site | Browser / GitHub | Full project URL? Latest run green? Hard refresh |
| Change missing on live site | GitHub / Browser | Merged to `main`? Wait for Actions · hard refresh |
| Issue didn’t close | GitHub | PR description must include `Closes #N` with the right number |
| `profile.js` SyntaxError | VS Code | Missing/extra comma — Undo, save, retry |

When stuck: show a helper your **VS Code** Status Bar branch name, **Terminal** `git status` output, and the first clear error line.

---

## Done when

- [ ] **Browser** · live URL opens and looks like *you* (not the sample person)
- [ ] **GitHub** · you can point to the **issue**, the **PR** (with `Closes #…`), and a **green Actions** run
- [ ] You did **not** paste secrets into Copilot or the repo

Optional (**VS Code** + Copilot): ask it to **explain** `profile.js` first, then request **one** focused edit — you review every line.
