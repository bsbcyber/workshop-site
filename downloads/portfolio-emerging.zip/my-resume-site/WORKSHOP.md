# Workshop 1 journey — follow along in VS Code

Open this file beside your editor (**View → Editor Layout → Two Columns**). Check boxes as you go.

**Where you work**

| Label | Meaning |
| --- | --- |
| **VS Code** | Clicks or typing inside Visual Studio Code |
| **Terminal** | The panel at the bottom of VS Code (or a second terminal tab) |
| **GitHub** | Your browser on github.com |
| **Browser** | Local preview (`localhost`) or your live site |

**Goal:** build out *your* resume in this starter → open a real pull request tied to an issue → publish on GitHub Pages.

---

## Before you start

- [ ] **GitHub** — signed in at [github.com](https://github.com)
- [ ] **VS Code** — installed and open
- [ ] **Terminal** (in VS Code) — these print version numbers:

```bash
git --version
node --version
npm --version
```

Prefer Node.js **22**. Node 18+ usually works locally.

**VS Code map:** Activity Bar (far left icons) · Side Bar · Editor (center) · Status Bar (very bottom — shows branch name).

---

## Step 1 — Open this folder · VS Code

You should already have unzipped the starter into `my-resume-site`.

- [ ] **VS Code** · **File → Open Folder…** → select `my-resume-site` (you should see `package.json`, `src`, `public`, `WORKSHOP.md`)
- [ ] **VS Code** · Trust the authors if asked
- [ ] **VS Code** · **Terminal → New Terminal**

---

## Step 2 — Create an empty repository · GitHub

- [ ] **GitHub** · open [github.com/new](https://github.com/new)
- [ ] **GitHub** · name it something like `my-resume-site`
- [ ] **GitHub** · choose **Public**
- [ ] **GitHub** · leave **Add a README**, license, and .gitignore **unchecked**
- [ ] **GitHub** · click **Create repository**
- [ ] **GitHub** · copy the HTTPS URL into a note  
  (`https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git`)

Do not push yet.

---

## Step 3 — Run locally, then first push · VS Code + Terminal + GitHub

### 3a · Preview · Terminal

```bash
npm install
npm run dev
```

- [ ] **Terminal** · wait until it finishes `npm install`
- [ ] **Browser** · open the `localhost` link from the terminal (usually `http://localhost:4321`)
- [ ] **Browser** · you see the sample resume

Keep that terminal running. In **VS Code**, click **+** in the terminal panel to open a **second** terminal for Git.

### 3b · First push · Terminal

In the **second** terminal, replace the remote URL with yours:

```bash
git init
git add .
git commit -m "Create my portfolio"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

- [ ] **GitHub** · refresh your repo — your files are there
- [ ] **GitHub** · **Actions** may show a **red X** on deploy. That is normal. Do **not** rewrite files to “fix” it yet — Pages is Step 6.

If Git says author identity unknown (**Terminal**):

```bash
git config --global user.name "Your Name"
git config --global user.email "YOUR-GITHUB-NOREPLY-EMAIL"
```

Then retry the commit. For push auth: **GitHub** browser sign-in, or a Personal Access Token with `repo` — **not** your GitHub password.

---

## Step 4 — Build out your resume · VS Code (+ Browser for preview)

Stay on `main`. **Do not Commit / Sync in Source Control yet.**

- [ ] **VS Code** · Explorer → `src` → `data` → `profile.js`
- [ ] **VS Code** · replace name, role, about, email, GitHub, LinkedIn (no `example.com` leftovers)
- [ ] **VS Code** · update skills, education, coursework, activities
- [ ] **VS Code** · leave `experience: []` if you have none yet
- [ ] **VS Code** · edit or add a project (include a `slug` like `inventory-tracker`)
- [ ] **VS Code** · optional: add `public/photo.jpg` and set `photo: '/photo.jpg'`
- [ ] **VS Code** · save (`Cmd`/`Ctrl`+`S`)
- [ ] **Browser** · refresh localhost · check desktop and narrow width
- [ ] **VS Code** · still **no Commit** on `main`

---

## Step 5 — Issue → branch → commit → pull request

Yes: you create a real GitHub **issue**, then a real **pull request**, and you **link them** so merging the PR closes the issue.

### 5a · Create the issue · GitHub

- [ ] **GitHub** · your repo → **Issues** → **New issue**
- [ ] **GitHub** · if you see **Featured project**, choose it (comes from this starter). Otherwise paste the template below.
- [ ] **GitHub** · click **Create**
- [ ] **GitHub** · note the issue number in the URL or title (e.g. `#1`)

#### Issue body — copy this

**Title:** `Add a featured project card`

```markdown
## What I’m adding or updating

Featured project card for: [your project name]

## Done when

- [ ] Project title and summary are honest (my real work)
- [ ] Link works (repo, demo, or doc) — not an example.com placeholder
- [ ] Looks readable on a phone-width browser window
- [ ] No secrets, passwords, or private personal details in the change

## Notes

[optional]
```

(Same text ships in `.github/ISSUE_TEMPLATE/featured-project.md` so GitHub can offer it automatically after your first push.)

### 5b · Create the branch · VS Code

- [ ] **VS Code** · Status Bar (bottom left) → click `main`
- [ ] **VS Code** · **Create new branch…** → type `add-featured-project` → Enter
- [ ] **VS Code** · Status Bar now shows `add-featured-project`

Your uncommitted Step 4 edits move with this branch.

### 5c · Match the issue · VS Code + Browser

- [ ] **VS Code** · finish the featured project (and any other resume edits) in `profile.js`
- [ ] **VS Code** · save
- [ ] **Browser** · refresh localhost and check it

### 5d · Commit and publish the branch · VS Code

- [ ] **VS Code** · Activity Bar → **Source Control** (branch icon)
- [ ] **VS Code** · click `profile.js` · read the green/red diff
- [ ] **VS Code** · **+** to Stage → message e.g. `Add featured project card` → **Commit**
- [ ] **VS Code** · **Publish Branch** (or Sync Changes) — approve **GitHub** sign-in if asked

### 5e · Open the pull request and tie it to the issue · GitHub

- [ ] **GitHub** · refresh the repo → yellow banner **Compare & pull request** (or **Pull requests → New**)
- [ ] **GitHub** · confirm **base:** `main` and **compare:** `add-featured-project`
- [ ] **GitHub** · paste this in the PR description (use **your** issue number):

```markdown
Closes #1

## Summary
Ships the featured project card and my resume personalization from Workshop 1.

## Tested
- [ ] Localhost looks right on desktop and narrow width
- [ ] Project / profile links are mine (not example.com)
```

`Closes #1` (or `#2`, etc.) is what **links the PR to the issue**. When you merge, GitHub **auto-closes** that issue.

- [ ] **GitHub** · **Create pull request**
- [ ] **GitHub** · open **Files changed** — does it match the issue?
- [ ] **GitHub** · on the issue page, confirm the PR appears under “Development” / linked pull requests
- [ ] **GitHub** · **Merge pull request** → **Confirm merge** → delete branch if offered
- [ ] **GitHub** · issue should show **Closed** (because of `Closes #…`)

---

## Step 6 — Actions and Pages · VS Code (look) + GitHub (click)

Your ZIP already includes `.github/workflows/deploy.yml`. You do not write YAML today.

### What the workflow does

1. **When:** push / merge to `main`
2. **Build:** `npm install` → `npm run build`
3. **Deploy:** publish to GitHub Pages  
   Feature branches do **not** publish.

### Turn Pages on

- [ ] **VS Code** · open `.github/workflows/deploy.yml` once so you recognize it
- [ ] **GitHub** · **Settings → Pages**
- [ ] **GitHub** · **Build and deployment → Source** = **GitHub Actions**
- [ ] **GitHub** · **Actions** tab → open **Build and deploy portfolio**
- [ ] **GitHub** · if it failed earlier: **Re-run all jobs**
- [ ] **GitHub** · wait for green
- [ ] **GitHub** · **Settings → Pages** → open the site URL  
  (`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`)
- [ ] **Browser** · check homepage, photo (if any), a project link, narrow window

---

## If something breaks

| Symptom | Where | Try this |
| --- | --- | --- |
| Push asks for a password | Terminal / GitHub | Browser login or PAT with `repo` — not your account password |
| Actions deploy failed | GitHub | Pages Source = GitHub Actions, then Re-run all jobs |
| 404 on the live site | Browser / GitHub | Full project URL? Latest run green? Hard refresh |
| Change missing on live site | GitHub / Browser | Merged to `main`? Wait for Actions · hard refresh |
| Issue didn’t close | GitHub | PR description must include `Closes #N` with the right number |
| `profile.js` SyntaxError | VS Code / Terminal | Missing/extra comma — Undo, save, retry |

When stuck: show a helper your **VS Code** Status Bar branch name, **Terminal** `git status`, and the first clear error line.

---

## Done when

- [ ] **Browser** · live URL opens and looks like *you* (not the sample person)
- [ ] **GitHub** · you can point to the **issue**, the **PR** (with `Closes #…`), and a **green Actions** run
- [ ] You did **not** paste secrets into Copilot or the repo

Optional (**VS Code** + Copilot): ask it to **explain** `profile.js` first, then request **one** focused edit — you review every line.
